﻿using Microsoft.EntityFrameworkCore;
using WebApiPerson.Models;

namespace WebApiPerson.Contenst
{
    public class AppbContext : DbContext
    {
        public AppbContext(DbContextOptions<AppbContext>options):base(options) { }
        public DbSet <Person> Persons { get; set; }
    }
}
